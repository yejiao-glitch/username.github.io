const pg = [{
        link: "https://m.pgsoft-games.com/1513328/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/58124.jpg",
        text: "超级高尔夫 ",
    },
    {
        link: "https://m.pgsoft-games.com/65/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/1.jpg",
        text: "麻将胡了1",
    },
    {
        link: "https://m.pgsoft-games.com/74/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/2.jpg",
        text: "麻将胡了2",
    },
    {
        link: "https://m.pgsoft-games.com/1402846/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/8881.jpg",
        text: "点石成金",
    },
    {
        link: "https://m.pgsoft-games.com/1543462/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/jqt.jpg",
        text: "金钱兔",
    },
    {
        link: "https://m.pgsoft-games.com/1420892/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/97.jpg",
        text: "电音派对",
    },
    {
        link: "https://m.pgsoft-games.com/1368367/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/4.jpg",
        text: "炼金工坊",
    },
    {
        link: "https://m.pgsoft-games.com/117/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/22.jpg",
        text: "夜醉佳人",
    },
    {
        link: "https://m.pgsoft-games.com/1418544/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/58121.jpg",
        text: "烘培总动员",
    },
    {
        link: "https://m.pgsoft-games.com/114/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/23.jpg",
        text: "超级表情包",
    },
    {
        link: "https://m.pgsoft-games.com/1312883/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/6.jpg",
        text: "黄金摇钱树",
    },
    {
        link: "https://m.pgsoft-games.com/116/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/24.jpg",
        text: "星际农场",
    },
    {
        link: "https://m.pgsoft-games.com/135/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/7.jpg",
        text: "赏金大对决",
    },
    {
        link: "https://m.pgsoft-games.com/119/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/25.jpg",
        text: "百鬼夜行",
    },
    {
        link: "https://m.pgsoft-games.com/132/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/8.jpg",
        text: "疯狂过山车",
    },
    {
        link: "https://m.pgsoft-games.com/107/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/26.jpg",
        text: "美猴王传奇",
    },
    {
        link: "https://m.pgsoft-games.com/128/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/9.jpg",
        text: "珀尔修斯传奇",
    },
    {
        link: "https://m.pgsoft-games.com/108/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/27.jpg",
        text: "美洲野牛",
    },
    {
        link: "https://m.pgsoft-games.com/127/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/10.jpg",
        text: "极速赢家",
    },
    {
        link: "https://m.pgsoft-games.com/124/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/13.jpg",
        text: "绝地大逃杀",
    },
    {
        link: "https://m.pgsoft-games.com/130/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/11.jpg",
        text: "电玩金猪",
    },
    {
        link: "https://m.pgsoft-games.com/120/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/14.jpg",
        text: "韩宫御宴",
    },
    {
        link: "https://m.pgsoft-games.com/129/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/12.jpg",
        text: "发财鱼虾蟹",
    },
    {
        link: "https://m.pgsoft-games.com/123/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/15.jpg",
        text: "斗鸡",
    },
    {
        link: "https://m.pgsoft-games.com/125/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/16.jpg",
        text: "蝶恋花",
    },
    {
        link: "https://m.pgsoft-games.com/121/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/17.jpg",
        text: "日月星辰",
    },
    {
        link: "https://m.pgsoft-games.com/122/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/18.jpg",
        text: "神鹰宝石",
    },
    {
        link: "https://m.pgsoft-games.com/113/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/29.jpg",
        text: "探秘埃及",
    },
    {
        link: "https://m.pgsoft-games.com/115/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/28.jpg",
        text: "超市大血拼",
    },
    {
        link: "https://m.pgsoft-games.com/102/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/31.jpg",
        text: "人鱼公主",
    },
    {
        link: "https://m.pgsoft-games.com/110/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/32.jpg",
        text: "恐龙帝国",
    },
    {
        link: "https://m.pgsoft-games.com/1448762/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/58122.jpg",
        text: "泰嗨泼水节",
    },
    {
        link: "https://m.pgsoft-games.com/101/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/34.jpg",
        text: "太阳神",
    },
    {
        link: "https://m.pgsoft-games.com/105/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/35.jpg",
        text: "霹雳神偷",
    },
    {
        link: "https://m.pgsoft-games.com/106/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/36.jpg",
        text: "麒麟送宝",
    },
    {
        link: "https://m.pgsoft-games.com/104/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/37.jpg",
        text: "亡灵大盗",
    },
    {
        link: "https://m.pgsoft-games.com/100/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/38.jpg",
        text: "糖心风暴",
    },
    {
        link: "https://m.pgsoft-games.com/95/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/39.jpg",
        text: "宝石传奇",
    },
    {
        link: "https://m.pgsoft-games.com/89/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/40.jpg",
        text: "招财喵",
    },
    {
        link: "https://m.pgsoft-games.com/88/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/41.jpg",
        text: "金玉满堂",
    },
    {
        link: "https://m.pgsoft-games.com/84/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/42.jpg",
        text: "赏金女王",
    },
    {
        link: "https://m.pgsoft-games.com/58/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/43.jpg",
        text: "古德拉女爵",
    },
    {
        link: "https://m.pgsoft-games.com/90/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/44.jpg",
        text: "艳后之谜",
    },
    {
        link: "https://m.pgsoft-games.com/92/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/45.jpg",
        text: "水上泰神奇",
    },
    {
        link: "https://m.pgsoft-games.com/80/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/46.jpg",
        text: "欢乐嘉年华",
    },
    {
        link: "https://m.pgsoft-games.com/87/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/47.jpg",
        text: "寻宝黄金城",
    },
    {
        link: "https://m.pgsoft-games.com/85/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/48.jpg",
        text: "阿拉丁神灯",
    },
    {
        link: "https://m.pgsoft-games.com/83/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/49.jpg",
        text: "火树赢花",
    },
    {
        link: "https://m.pgsoft-games.com/79/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/50.jpg",
        text: "澳门壕梦",
    },
    {
        link: "https://m.pgsoft-games.com/82/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/51.jpg",
        text: "凤凰传奇",
    },
    {
        link: "https://m.pgsoft-games.com/75/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/52.jpg",
        text: "福运象财神",
    },
    {
        link: "https://m.pgsoft-games.com/73/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/53.jpg",
        text: "埃及探秘宝典",
    },
    {
        link: "https://m.pgsoft-games.com/69/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/54.jpg",
        text: "比基尼天堂",
    },
    {
        link: "https://m.pgsoft-games.com/71/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/55.jpg",
        text: "赢财神",
    },
    {
        link: "https://m.pgsoft-games.com/70/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/56.jpg",
        text: "糖果连连爆",
    },
    {
        link: "https://m.pgsoft-games.com/67/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/57.jpg",
        text: "少林足球",
    },
    {
        link: "https://m.pgsoft-games.com/62/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/58.jpg",
        text: "宝藏征途",
    },
    {
        link: "https://m.pgsoft-games.com/20/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/59.jpg",
        text: "亲爱的",
    },
    {
        link: "https://m.pgsoft-games.com/68/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/60.jpg",
        text: "鼠鼠福福",
    },
    {
        link: "https://m.pgsoft-games.com/57/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/61.jpg",
        text: "寻龙探宝",
    },
    {
        link: "https://m.pgsoft-games.com/3/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/62.jpg",
        text: "横财来啦",
    },
    {
        link: "https://m.pgsoft-games.com/28/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/63.jpg",
        text: "麻辣火锅",
    },
    {
        link: "https://m.pgsoft-games.com/29/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/64.jpg",
        text: "鱼跃龍門",
    },
    {
        link: "https://m.pgsoft-games.com/35/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/65.jpg",
        text: "万胜狂欢夜",
    },
    {
        link: "https://m.pgsoft-games.com/26/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/66.jpg",
        text: "摇钱树",
    },
    {
        link: "https://m.pgsoft-games.com/34/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/67.jpg",
        text: "后裔射日",
    },
    {
        link: "https://m.pgsoft-games.com/24/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/68.jpg",
        text: "旺旺旺",
    },
    {
        link: "https://m.pgsoft-games.com/25/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/69.jpg",
        text: "抓抓乐",
    },
    {
        link: "https://m.pgsoft-games.com/18/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/70.jpg",
        text: "逆袭小红帽",
    },
    {
        link: "https://m.pgsoft-games.com/17/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/71.jpg",
        text: "巫师之书",
    },
    {
        link: "https://m.pgsoft-games.com/2/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/72.jpg",
        text: "宝石侠",
    },
    {
        link: "https://m.pgsoft-games.com/36/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/73.jpg",
        text: "舞狮进宝",
    },
    {
        link: "https://m.pgsoft-games.com/63/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/74.jpg",
        text: "龍虎",
    },
    {
        link: "https://m.pgsoft-games.com/33/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/75.jpg",
        text: "嘻哈熊猫",
    },
    {
        link: "https://m.pgsoft-games.com/38/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/76.jpg",
        text: "宝石侠大宝剑",
    },
    {
        link: "https://m.pgsoft-games.com/39/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/77.jpg",
        text: "金猪报财",
    },
    {
        link: "https://m.pgsoft-games.com/41/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/78.jpg",
        text: "埃及寻宝",
    },
    {
        link: "https://m.pgsoft-games.com/44/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/79.jpg",
        text: "皇上吉祥",
    },
    {
        link: "https://m.pgsoft-games.com/42/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/80.jpg",
        text: "象财神",
    },
    {
        link: "https://m.pgsoft-games.com/43/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/81.jpg",
        text: "3只猴子",
    },
    {
        link: "https://m.pgsoft-games.com/48/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/82.jpg",
        text: "双囍临门",
    },
    {
        link: "https://m.pgsoft-games.com/53/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/83.jpg",
        text: "冰雪大冲关",
    },
    {
        link: "https://m.pgsoft-games.com/50/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/84.jpg",
        text: "嘻游记",
    },
    {
        link: "https://m.pgsoft-games.com/54/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/85.jpg",
        text: "赏金船长",
    },
    {
        link: "https://m.pgsoft-games.com/1/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/86.jpg",
        text: "夜戏貂蝉",
    },
    {
        link: "https://m.pgsoft-games.com/60/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/87.jpg",
        text: "爱尔兰精灵",
    },
    {
        link: "https://m.pgsoft-games.com/61/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/88.jpg",
        text: "唐伯点虎秋香",
    },
    {
        link: "https://m.pgsoft-games.com/59/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/89.jpg",
        text: "忍者VS武士",
    },
    {
        link: "https://m.pgsoft-games.com/64/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/90.jpg",
        text: "拳霸",
    },
    {
        link: "https://m.pgsoft-games.com/97/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/91.jpg",
        text: "冰封奇侠",
    },
    {
        link: "https://m.pgsoft-games.com/86/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/92.jpg",
        text: "星旅淘金",
    },
    {
        link: "https://m.pgsoft-games.com/91/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/93.jpg",
        text: "冰火双娇",
    },
    {
        link: "https://m.pgsoft-games.com/98/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/94.jpg",
        text: "十倍金牛",
    },
    {
        link: "https://m.pgsoft-games.com/93/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/95.jpg",
        text: "新国粹",
    },
    {
        link: "https://m.pgsoft-games.com/103/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/96.jpg",
        text: "比特淘金",
    },
    {
        link: "https://m.pgsoft-games.com/126/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/19.jpg",
        text: "虎虎生财",
    },
    {
        link: "https://m.pgsoft-games.com/112/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/20.jpg",
        text: "江山美景图",
    },
    {
        link: "https://m.pgsoft-games.com/1372643/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/3.jpg",
        text: "美食美刻",
    },
    {
        link: "https://m.pgsoft-games.com/118/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/21.jpg",
        text: "假面嘉年华",
    },
    {
        link: "https://m.pgsoft-games.com/1340277/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/1041.jpg",
        text: "维京纪元",
    },
    {
        link: "https://m.pgsoft-games.com/1338274/index.html?language=zh&amp;bet_type=1&amp;operator_token=ca7094186b309ee149c55c8822e7ecf2&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com&amp;btt=2&amp;__refer=m.pg-redirect.net&amp;or=static.pgsoft-games.com",
        img: "./img/pg/5.jpg",
        text: "图腾奇迹",
    },
];
const pp = [{
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20sugarrush&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fen%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/jstg.jpg",
        text: "极速糖果",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20olympgate&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/alpszm.jpg",
        text: "奥林匹斯之门",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayslions&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/5js.jpg",
        text: "5金狮",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs10mayangods&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/yhlrymysj.jpg",
        text: "约翰猎人与玛雅神迹",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs10bookoftut&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/yhhtzajtts.jpg",
        text: "约翰.亨特之埃及图特书",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysfltdrg&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/yylm.jpg",
        text: "鱼跃龙门",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayslofhero&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/yxlm.jpg",
        text: "英雄联盟",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysfrywld&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/xzjslm.jpg",
        text: "旋转及射龙门",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysluckyfish&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/xyby.jpg",
        text: "幸运捕鱼",
    },
    {
        link: "https://88s.me/ppdz/httpsdemogamesfree.pragmaticplay.netgs2copenGame.dogameSymbol=vs117649starz&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/xb.jpg",
        text: "星爆",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysbufking&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/xbnzhjdd.jpg",
        text: "西部牛仔黄金地段",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysbufking&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/wzyn.jpg",
        text: "王者野牛",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20doghousemh&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/wwzjdfwck.jpg",
        text: "汪汪之家多方位持控",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysdogs&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/wwzj.jpg",
        text: "汪汪之家",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20clspwrndg&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/tppd.jpg",
        text: "甜品派对",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayscryscav&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/sjdx.jpg",
        text: "水晶洞穴",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20xmascarol&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/sdsg.jpg",
        text: "圣诞颂歌 ",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs10amm&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/qhwbjqqkj.jpg",
        text: "奇幻无比金钱取款机",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20muertos&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/mxgwlj.jpg",
        text: "墨西哥亡灵节",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysmadame&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/mynw.jpg",
        text: "命运女巫",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20mammoth&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/mmhj.jpg",
        text: "猛犸黄金",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayshammthor&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/lszc.jpg",
        text: "雷神之锤",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayswerewolf&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/lrdzz.jpg",
        text: "狼人的诅咒",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysyumyum&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/kkhc.jpg",
        text: "可口好吃",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayssamurai&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/jqdws.jpg",
        text: "崛起的武士",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs10nudgeit&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/jsjzt.jpg",
        text: "吉萨金字塔",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs50hercules&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/zszz.jpg",
        text: "宙斯之子",
    },
    {
        link: "https://88s.me/ppdz/httpsdemogamesfree-asia.pragmaticplay.netgs2copenGame.dogameSymbol=vswaysaztecking&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/aztkwg.jpg",
        text: "阿兹特克王国",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayswwriches&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/aelrbz.jpg",
        text: "爱尔兰人宝藏",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs12bbbxmas&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/cjdlybfy.jpg",
        text: "超级大鲈鱼暴风雨",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswayschilheat&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/cjlj.jpg",
        text: "超级辣椒",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysxjuicy&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/ewdz.jpg",
        text: "额外多汁",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysbbb&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/fgdly.jpg",
        text: "疯狂大鲈鱼",
    },
    {
        link: "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs9aztecgemsdx&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/gdbsjqb.jpg",
        text: "古代宝石加强版",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs40pirgold&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/hjhdjqb.jpg",
        text: "黄金海盗加强版",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysoldminer&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/hjlkg.jpg",
        text: "黄金老矿工",
    },
    {
        link: "https://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vswaysconcoll&amp;websiteUrl=https%3A%2F%2Fdemogamesfree.pragmaticplay.net&amp;jurisdiction=99&amp;lobby_url=https%3A%2F%2Fwww.pragmaticplay.com%2Fzh%2F&amp;lang=ZH&amp;cur=CNY",
        img: "./img/pp/hnjs.jpg",
        text: "火鸟精神",
    },
];
const jdb = [{
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=81",
        img: "./img/jdb/xjsgb.jpg",
        text: "星际水果霸",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=79",
        img: "./img/jdb/tjcs.jpg",
        text: "天降财神",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=77",
        img: "./img/jdb/ggnc.jpg",
        text: "咕咕农场",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=76",
        img: "./img/jdb/ysjs.jpg",
        text: "元素连接水",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=75",
        img: "./img/jdb/ysljh.jpg",
        text: "元素连接火",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=74",
        img: "./img/jdb/fqpd1.jpg",
        text: "飞鸟豪华派对",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=71",
        img: "./img/jdb/fhg2.jpg",
        text: "富豪哥2",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=70",
        img: "./img/jdb/wp11.jpg",
        text: "王牌",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=69",
        img: "./img/jdb/xyzcm.jpg",
        text: "幸运招财猫",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=67",
        img: "./img/jdb/smzs.jpg",
        text: "神秘之书",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=66",
        img: "./img/jdb/skhb.jpg",
        text: "烧烤汉堡",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=63",
        img: "./img/jdb/hhsf.jpg",
        text: "虎虎生丰",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=62",
        img: "./img/jdb/bfm.jpg",
        text: "白富美",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=61",
        img: "./img/jdb/xh11.jpg",
        text: "星航",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=60",
        img: "./img/jdb/hkfg.jpg",
        text: "花开富贵",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=59",
        img: "./img/jdb/bbpd.jpg",
        text: "爆爆派对",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=58",
        img: "./img/jdb/dsy.jpg",
        text: "大三元",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=57",
        img: "./img/jdb/dgzz.jpg",
        text: "帝国战争",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=56",
        img: "./img/jdb/cfdl.jpg",
        text: "财富灯笼",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=55",
        img: "./img/jdb/myjfk.jpg",
        text: "玛雅金疯狂",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=54",
        img: "./img/jdb/cn4.jpg",
        text: "超能4",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=53",
        img: "./img/jdb/fxcf.jpg",
        text: "飞象财富",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=52",
        img: "./img/jdb/blxd.jpg",
        text: "暴龙兄弟",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=51",
        img: "./img/jdb/rz11.jpg",
        text: "忍者",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=48",
        img: "./img/jdb/jg11.jpg",
        text: "金刚",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=46",
        img: "./img/jdb/clhb.jpg",
        text: "丛林活宝",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=45",
        img: "./img/jdb/cjz.jpg",
        text: "超级钻",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=44",
        img: "./img/jdb/lylm.jpg",
        text: "鲤越龙门",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=43",
        img: "./img/jdb/lh12.jpg",
        text: "浪花2",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=42",
        img: "./img/jdb/lh11.jpg",
        text: "浪花",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=3",
        img: "./img/jdb/bl22.jpg",
        text: "变脸2",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=24",
        img: "./img/jdb/tbhdqx2.jpg",
        text: "唐伯虎点秋香2",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=41",
        img: "./img/jdb/sgbbl.jpg",
        text: "水果爆爆乐",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=40",
        img: "./img/jdb/lhbd.jpg",
        text: "龙湖百搭",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=39",
        img: "./img/jdb/ckbb.jpg",
        text: "采矿宝贝",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=38",
        img: "./img/jdb/fhg.jpg",
        text: "富豪哥",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=35",
        img: "./img/jdb/bdb.jpg",
        text: "蹦迪吧",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=34",
        img: "./img/jdb/cjnb.jpg",
        text: "超级牛逼豪华版",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=33",
        img: "./img/jdb/ggjg.jpg",
        text: "古怪金刚",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=32",
        img: "./img/jdb/lszc.jpg",
        text: "雷神之锤",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=31",
        img: "./img/jdb/jbp.jpg",
        text: "聚宝盆",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=27",
        img: "./img/jdb/qhdb.jpg",
        text: "七海夺宝",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=26",
        img: "./img/jdb/kydb.jpg",
        text: "开运夺宝",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=25",
        img: "./img/jdb/flzt.jpg",
        text: "飞龙在天",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=23",
        img: "./img/jdb/ygmb.jpg",
        text: "月光秘宝",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=22",
        img: "./img/jdb/gxn.jpg",
        text: "过新年",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=21",
        img: "./img/jdb/glf.jpg",
        text: "狗来福",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=20",
        img: "./img/jdb/lw88.jpg",
        text: "龙舞",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=19",
        img: "./img/jdb/msyq.jpg",
        text: "马上有钱",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=14",
        img: "./img/jdb/dfss.jpg",
        text: "东方神兽",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=13",
        img: "./img/jdb/hy777.jpg",
        text: "好运777",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=12",
        img: "./img/jdb/zmkm.jpg",
        text: "芝麻开门",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=11",
        img: "./img/jdb/mqws.jpg",
        text: "麻雀无双",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=10",
        img: "./img/jdb/twhx.jpg",
        text: "台湾黑熊",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=9",
        img: "./img/jdb/jjbx.jpg",
        text: "金鸡报喜",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=8",
        img: "./img/jdb/bl.jpg",
        text: "变脸",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=7",
        img: "./img/jdb/tbhdqx.jpg",
        text: "唐伯虎点秋香",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=4",
        img: "./img/jdb/fnpd11.jpg",
        text: "飞鸟派对",
    },
    {
        link: "https://api.jdbgaming.com/game/demo?lang=zh-CN&amp;id=2",
        img: "./img/jdb/zmkm2.jpg",
        text: "芝麻开门2",
    },
];
const bbin = [{
        link: "https://bb-guest.com:5569/game/game.php?GameType=5262&amp;lang=zh-cn",
        img: "./img/bbin/5262.png",
        text: "豪赌神猫",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5261&amp;lang=zh-cn",
        img: "./img/bbin/5261.png",
        text: "招财喵喵",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5259&amp;lang=zh-cn",
        img: "./img/bbin/5259.png",
        text: "爆利金刚",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5260&amp;lang=zh-cn",
        img: "./img/bbin/5260.png",
        text: "金钱树",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5902&amp;lang=zh-cn",
        img: "./img/bbin/5902.png",
        text: "糖果派对",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5210&amp;lang=zh-cn",
        img: "./img/bbin/5908.png",
        text: "糖果缤纷乐",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5908&amp;lang=zh-cn",
        img: "./img/bbin/5171.png",
        text: "糖果派对2",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5175&amp;lang=zh-cn",
        img: "./img/bbin/5175.png",
        text: "满天星",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5231&amp;lang=zh-cn",
        img: "./img/bbin/5231.png",
        text: "聚宝消消乐",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5901&amp;lang=zh-cn",
        img: "./img/bbin/5901.png",
        text: "连环夺宝",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5222&amp;lang=zh-cn",
        img: "./img/bbin/5222.png",
        text: "疯狂果酱罐",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5198&amp;lang=zh-cn",
        img: "./img/bbin/5198.png",
        text: "下龙湾神话",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5601&amp;lang=zh-cn",
        img: "./img/bbin/5601.png",
        text: "秘境冒险",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5200&amp;lang=zh-cn",
        img: "./img/bbin/5200.png",
        text: "鱼虾蟹开了",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5837&amp;lang=zh-cn",
        img: "./img/bbin/5837.png",
        text: "喜福猴年",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5903&amp;lang=zh-cn",
        img: "./img/bbin/5903.png",
        text: "秦皇秘宝",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5128&amp;lang=zh-cn",
        img: "./img/bbin/5128.png",
        text: "多福多财",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5193&amp;lang=zh-cn",
        img: "./img/bbin/5193.png",
        text: "糖果吧",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5835&amp;lang=zh-cn",
        img: "./img/bbin/5835.png",
        text: "喜福牛年",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5185&amp;lang=zh-cn",
        img: "./img/bbin/5185.png",
        text: "大丰收",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5191&amp;lang=zh-cn",
        img: "./img/bbin/5191.png",
        text: "猪宝满满",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5076&amp;lang=zh-cn",
        img: "./img/bbin/5076.png",
        text: "数字大转轮",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5253&amp;lang=zh-cn",
        img: "./img/bbin/5253.png",
        text: "爆发富",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5045&amp;lang=zh-cn",
        img: "./img/bbin/5045.png",
        text: "森林舞会",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5242&amp;lang=zh-cn",
        img: "./img/bbin/5242.png",
        text: "舞狮夺宝",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5250&amp;lang=zh-cn",
        img: "./img/bbin/5250.png",
        text: "采矿飞车",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5254&amp;lang=zh-cn",
        img: "./img/bbin/5254.png",
        text: "黄金传说",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5213&amp;lang=zh-cn",
        img: "./img/bbin/5213.png",
        text: "富贵金蟾",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5106&amp;lang=zh-cn",
        img: "./img/bbin/5106.png",
        text: "三国",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5216&amp;lang=zh-cn",
        img: "./img/bbin/5216.png",
        text: "人鱼秘宝",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5234&amp;lang=zh-cn",
        img: "./img/bbin/5234.png",
        text: "超牛逼",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5208&amp;lang=zh-cn",
        img: "./img/bbin/5208.png",
        text: "宾果消消乐",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5205&amp;lang=zh-cn",
        img: "./img/bbin/5205.png",
        text: "轰炸乐园",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5407&amp;lang=zh-cn",
        img: "./img/bbin/5407.png",
        text: "大红帽与小野狼",
    },
    {
        link: "https://bb-guest.com:5569/game/game.php?GameType=5246&amp;lang=zh-cn",
        img: "./img/bbin/5246.png",
        text: " Go!Go!筋斗云",
    },
];
const ps = [{
        link: "https://download.iplaystar.net/PSS-ON-00141/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/MJHL3.png",
        text: "麻将胡了3",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00139/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/SSEH.png",
        text: "食神二哈",
    },
    {
        link: "https://download.iplaystar.net/PSM-ON-00001/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/CSD.png",
        text: "财神到水果机",
    },
    {
        link: "https://download.iplaystar.net/PSM-ON-00006/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DJB.png",
        text: "财神淘金",
    },
    {
        link: "https://download.iplaystar.net/PSM-ON-00015/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DJB2.png",
        text: "财神淘金2",
    },
    {
        link: "https://download.iplaystar.net/PSM-ON-00015/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/PPN.png",
        text: "跑跑牛",
    },
    {
        link: "https://download.iplaystar.net/PSM-ON-00008/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DFW.png",
        text: "大富翁水果机",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-20002/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/MLBY.png",
        text: "麻辣捕鱼PRO",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00108/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/QSYCS.png",
        text: "全鼠迎财神",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00107/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/CJZ.png",
        text: "超级炸",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00135/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DTZ1.png",
        text: "大挑战喜猪",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00137/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/CJYS.png",
        text: "超级有势",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00135/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DTZ4.png",
        text: "大挑战喜猪BE",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00101/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DTZ2.png",
        text: "大挑战福禄",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00099/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DTZ3.png",
        text: "大挑战玛雅",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00095/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/MJDX.png",
        text: "麻将大侠",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00115/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/MJFFF.png",
        text: "麻将发发发",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00090/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/BSZC.png",
        text: "宝石之城",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00019/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/TZ.png",
        text: "天子",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00032/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/777HY.png",
        text: "777火焰",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00068/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/FLZT.png",
        text: "飞龙在天",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00067/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DWJ.png",
        text: "端午节",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00065/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/CJYQ.png",
        text: "超级有钱",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00133/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/JBDR.png",
        text: "金币达人",
    },
    {
        link: "https://download.iplaystar.net/PSTM-ON-00003/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/LXX.png",
        text: "转运消消乐",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00116/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/WUJLB2.png",
        text: "舞娘俱乐部2",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-00007/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/HWMB.png",
        text: "海王秘宝",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-00002/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/MLBY.png",
        text: "麻辣捕鱼",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-00004/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/DPDBY.png",
        text: "捕鱼大排档",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-00003/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/LYDR.png",
        text: "猎鹰达人",
    },
    {
        link: "https://download.iplaystar.net/PSF-ON-00005/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/TGBYW.png",
        text: "泰国捕鱼王",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00123/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/BFBZ.png",
        text: "百发百粽",
    },
    {
        link: "https://download.iplaystar.net/PSS-ON-00038/?access_token=(*--)6e72982bb3f9da8cce7650cde97b53c1&amp;lang=sch&amp;ccy=NON&amp;sm=00&amp;subid=0&amp;fullscr=1&amp;lc=zh-CN&amp;pm=1&amp;ns=0&amp;origin=https%3a%2f%2fdemo-api.iplaystar.net&amp;anal=10&amp;lb=1&amp;stf=0&amp;showver=1",
        img: "./img/ps/BL.png",
        text: "变脸",
    },
];
const utils = [{
        title: "椰子接码平台",
        info: "价格低廉,用多少冲多少",
        imgUrl: "./img/sms-2.jpg",
        link: "http://h5.yezi66.net:90/invite/805196",
    },
    {
        title: "俄罗斯接码平台",
        info: "国际平台几十年不跑路，需VPN访问",
        imgUrl: "./img/sms.jpg",
        link: "https://sms-activate.io/?ref=9665114",
    },
    {
        title: "QQ查手机号",
        info: "通过QQ号可查询所绑定的手机号",
        imgUrl: "./img/qq.jpg",
        link: "https://zy.xywlapi.cc/home.html",
    },
    {
        title: "USDT交易查询",
        info: "查询USDT转账明细与哈希值",
        imgUrl: "./img/u-2.webp",
        link: "https://chahaxi.com.cn/",
    },
    {
        title: "手机号查IP",
        info: "查询手机号归属地，IP详细信息查询",
        imgUrl: "./img/ip.webp",
        link: "https://m.ip138.com/",
    },
    {
        title: "域名信息查询",
        info: "查询域名各种信息，如绑定信息等",
        imgUrl: "./img/yumin.webp",
        link: "https://who.cx",
    },
    {
        title: "USDT模拟器",
        info: "提供仿真虚拟币，骗狗庄必备",
        imgUrl: "./img/u-1.webp",
        link: "https://YF28.cc/app/usdt模拟器.apk",
    },
    {
        title: "中国银行模拟器",
        info: "提供仿真中国银行，骗狗庄必备",
        imgUrl: "./img/zg.jpg",
        link: "https://YF28.cc/app/中国yh.apk",
    },
    {
        title: "工商银行模拟器",
        info: "提供仿真工商银行，骗狗庄必备",
        imgUrl: "./img/gs.jpg",
        link: "https://YF28.cc/app/工商yh.apk",
    },
    {
        title: "广东农信模拟器",
        info: "提供仿真广东农信，骗狗庄必备",
        imgUrl: "./img/nx.jpg",
        link: "https://YF28.cc/app/广东农信yh.apk",
    },
    {
        title: "中信银行模拟器",
        info: "提供仿真中信银行，骗狗庄必备",
        imgUrl: "./img/zx.jpg",
        link: "https://YF28.cc/app/中兴yh.apk",
    },
    {
        title: "农业银行模拟器",
        info: "提供仿真农业银行，骗狗庄必备",
        imgUrl: "./img/ny.jpg",
        link: "https://YF28.cc/app/农业yh.apk",
    },
    {
        title: "云闪付模拟器",
        info: "提供仿真云闪付，骗狗庄必备",
        imgUrl: "./img/ysf.jpg",
        link: "https://YF28.cc/app/云闪付app.apk",
    },
];
const app = [{
        title: "Telegrame",
        info: "国际平台几十年不跑路，需VPN访问",
        imgUrl: "./img/fj.jpg",
        link: "https://telegram.org/dl",
    },
    {
        title: "旺旺商聊",
        info: "通过QQ号可查询所绑定的手机号",
        imgUrl: "./img/ww.jpg",
        link: "https://www.mechatmall.com",
    },
    {
        title: "MosGram",
        info: "查询USDT转账明细与哈希值",
        imgUrl: "./img/mos.jpg",
        link: "https://ya.cn/index.html",
    },
    {
        title: "Meetalk",
        info: "查询USDT转账明细与哈希值",
        imgUrl: "./img/met.jpg",
        link: "https://meetlak.com/index.html",
    },
    {
        title: "Edge浏览器",
        info: "查询USDT转账明细与哈希值",
        imgUrl: "./img/edge.jpg",
        link: "https://www.microsoft.com/zh-tw/edge/download?form=MD18G4",
    },
    {
        title: "谷歌浏览器",
        info: "查询USDT转账明细与哈希值",
        imgUrl: "./img/gol.jpg",
        link: "https://www.google.cn/chrome/index.html",
    },
];
const yh = [{
        title: "星云200+200",
        info: "冲200送200申请入口(先注册绑卡)",
        imgUrl: "./img/dd.jpg",
        link: "./dd28.html",
    },
    {
        title: "PG大满贯",
        info: "注册送申请入口(先注册绑卡)",
        imgUrl: "./img/1h.jpg",
        link: "http://dmg40.cc",
    },
    {
        title: "财神国际",
        info: "注册送申请入口(先注册绑卡)",
        imgUrl: "./img/ty.jpg",
        link: "http://c037.top",
    },
    {
        title: "开元棋牌",
        info: "注册送申请入口(先注册绑卡)",
        imgUrl: "./img/yh.jpg",
        link: "http://ky6465.vip",
    },
];